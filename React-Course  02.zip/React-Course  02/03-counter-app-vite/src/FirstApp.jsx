// export function App() {
//     return <h1>Hola Mundo</h1>
// }

import React from 'react'

export const FirstApp = () => {
  return (
    <div><h1>FirstApp</h1></div>
  )
}

// export const FirstApp = ()=> <h1>First App</h1>