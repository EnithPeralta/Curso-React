const activo = true;
// let menssage = ''

// if (activo) {
//     menssage = 'Activo';
// } else {
//     menssage = 'Inactivo';
// }



// const menssage = {activo}?'Activo':'Inactivo';

const menssage = !activo && 'Activo';

console.log(menssage)