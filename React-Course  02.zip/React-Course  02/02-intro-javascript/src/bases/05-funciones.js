// Funciones en JS
// No se debe crear funciones de esta manera 
// function saludar(nombre) {
//     return `Hola,${nombre}`
// }

const saludar = function (nombre) {
    return `Hola,${nombre}`
}
const saludar2 =(nombre) =>{
    return `Hola,${nombre}`
}

const saludar3 =(nombre) =>`Hola,${nombre}`;
const saludar4 =() =>`Hola universo`;


console.log(saludar('Mister Satan')) 
console.log(saludar2('Goku')) 
console.log(saludar3('Vegeta')) 
console.log(saludar4()) 

const getUser = ()=>{
    return {
        uid:'ABC123',
        username:'El_papi1502'
    }
}
const user = getUser();
console.log(user)


const getUserActivo = (nombre)=>({
    uid:'ABC456',
    username:nombre
});

const UserActivo = getUserActivo('Maria');
console.log(UserActivo)