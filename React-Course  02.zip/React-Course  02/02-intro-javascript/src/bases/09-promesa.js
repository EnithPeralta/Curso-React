import { getHeroeById } from "./bases/08-imp-exp";
import heroes from "./data/heroes";

// const promesa = new Promise((resolve,reject)=>{
//     setTimeout(()=>{
//         const heroe = getHeroeById(2)
//        resolve(heroe)
//         // reject('No se puedo manejar ese error');
//     }, 2000 )
// });
// promesa.then((heroe)=>{ 
//     console.log('Heroe',heroe)
// }).catch(e=> console.warn(e))


const getHeroeByIdAsync = (id) =>{
    return new Promise((resolve,reject)=>{
        setTimeout(()=>{
            const heroe = getHeroeById(id);
            if (heroe) {
                resolve(heroe)
            } else {
                reject('No se puedo manejar ese error');
            }
        }, 2000 )
    });
}
getHeroeByIdAsync(2)
.then(console.log)
.catch(console.warn)
