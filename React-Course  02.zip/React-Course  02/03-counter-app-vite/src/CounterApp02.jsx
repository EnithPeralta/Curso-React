import PropTypes from 'prop-types'

export const CounterApp02 = ({apellido}) => {
  return (
    <>
        <h1>CounterApp02</h1>
        <h2>{apellido}</h2>
    </>
  )
}

CounterApp02.protoTypes = {
    apellido:PropTypes.string.isRequired
}
