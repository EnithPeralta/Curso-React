import { useEffect } from "react"

export const Message = () => {

    useEffect(() => {

        
        window.addEventListener('mousemove',(e)=>{
        console.log(e.x, e.y);
    })    
      return () => {
      }
    }, [])
    
  return (
    <>
        <h3>Usuario ya exite</h3>
    </>
  )
}
