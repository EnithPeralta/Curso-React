const nombre = 'Maria Enith';
const apellido = 'Peralta Mosquera';

// const nombreCompleto = nombre + ' ' + apellido;
const nombreCompleto = `${nombre} 
${apellido}
${1+1}`;
console.log(nombreCompleto); 

function getSaludo(nombre) {
    return 'Hola soy' + nombre;
}

console.log(`Este es un texto: ${ getSaludo( nombre ) }`)
