// Variable y Constantes 

const nombre = 'Maria';
const apellido = 'Peralta';

let valDado = 5
valDado = 4

if (true) {
    let valDado = 6;
    console.log(valDado)
}

console.log(nombre, apellido, valDado)