module.exports = {
    transform: {
        '^.+\\.jsx?$': 'babel-jest', // Asegura que Jest transforme los archivos JSX/JS con Babel
      },
    testEnvironment: 'jest-environment-jsdom',
}
