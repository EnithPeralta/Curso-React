import { useCounter } from "../hooks/useCounter";

export const CouterWithCustomHook = () => {
  
    const {counter, increment, decremente, reset} = useCounter();
  
    return (
    <>
        <h1>Counter With Hook: {counter} </h1>
        <hr />
        <button className='btn btn-outline-info' onClick = {()=>increment()}>+1</button>
        <button className='btn btn-outline-info' onClick={reset}>Reset</button>
        <button className='btn btn-outline-info' onClick={()=>decremente()}>-1</button>
    </>
  )
}
