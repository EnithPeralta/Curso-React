import { render, screen, fireEvent } from '@testing-library/react';
import { GifExpertApp } from '../src/GifExpertApp';

test('debe mostrar el título y la categoría inicial', () => {
    render(<GifExpertApp />);
    expect(screen.getByText('GifExpertApp'));
    expect(screen.getByText('One Punch'))
});

test('debe agregar una nueva categoría si no está en el estado', () => {
    render(<GifExpertApp />);
    const input = screen.getByRole('textbox');
    const form = screen.getByRole('form');
    fireEvent.input(input, { target: { value: 'Dragon Ball' } });
    fireEvent.submit(form);
    expect(screen.getByText('Dragon Ball'))
    expect(screen.getByText('One Punch'))
});

test('no debe agregar una categoría si ya existe en el estado', () => {
    render(<GifExpertApp />);
    const input = screen.getByRole('textbox');
    const form = screen.getByRole('form');
    fireEvent.input(input, { target: { value: 'One Punch' } });
    fireEvent.submit(form);
    const items = screen.getAllByText('One Punch');
    expect(items.length).toBe(1);
});
