export function getSaludo(nombre) {
    return 'Hola ' + nombre;
}

