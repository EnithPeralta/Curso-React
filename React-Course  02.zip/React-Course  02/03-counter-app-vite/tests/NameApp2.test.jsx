import { render , screen} from "@testing-library/react";
import { NameApp } from "../src/NameApp";

describe('Pruebas en <NameApp2/>', () => { 
    const title = 'Hola, Soy Goku';
    const subTitle = 'Soy un subtitulo';

    
    test('debe de hacer match en el snapshot', () => { 
        const {container} = render(<NameApp title={title}/>);
        expect(container).toMatchSnapshot();
    });

    test('debe de mostrar el mensaje "Hola, Soy Goku', () => { 
      render(<NameApp title={title}/>);
      expect(screen.getByText(title)).toBeTruthy();
      
    })

    test('debe de mostrar el titulo en un h1', () => { 
      render(<NameApp title={title} />);
      expect(screen.getByRole('heading',{ level:1 }).innerHTML).toContain(title)
    });
    
    test('debe de mostrar el subtitulo enviado por las props', () => { 
      render(<NameApp title={title}  subTitle={subTitle}/>);
      expect(screen.getAllByText(subTitle).length).toBe(2)
    })

});
