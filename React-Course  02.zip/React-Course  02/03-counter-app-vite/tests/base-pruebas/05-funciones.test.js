import { getUser, getUsuarioActivo } from "../../src/base-pruebas/05-funciones"

describe('Prueba e 05-funciones',()=>{
    test('getUser debe de retonar un objecto', () => { 
        const testUser = {
            uid: 'ABC123',
            username: 'El_Papi1502'
        }
        const user = getUser();
        expect(testUser).toStrictEqual(user)
     })
     
    test('getUserActivo debe de retonar un objecto', () => { 
        const nombre = 'Maria'
        const user = getUsuarioActivo(nombre);
        expect (user).toStrictEqual({
            uid: 'ABC567',
            username: nombre
        });
    });
})
