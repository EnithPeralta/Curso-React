const persona ={
    nombre: 'Marcos',
    apellido:'Polo',
    edad:23,
    direccion:{
        cuidad:'New York',
        zip:52264818,
        lat:14.4938,
        lng:35.487120,
    }
}
// console.table({persona})
console.log({persona})

const persona2 = {...persona};
persona2.nombre ='Martin';
persona2.apellido ='Tejadas';

console.log({persona2})