import PropTypes from "prop-types";

// const newCurso = ()=>
//     {return 5*9}

export const NameApp = ({title,subTitle, name} ) => {

    //  console.log(title)
  return (
    <>
    <h1 data-testid = 'test-title'>{title}</h1>
        {/* <code>{JSON.stringify(newMessage)}</code> */}
        <p>{subTitle }</p>
        <p>{subTitle }</p>
        <p>{ name }</p>

    </>

  )
}

NameApp.protoTypes ={
  title:PropTypes.string.isRequired,
  subTitle:PropTypes.string
}

NameApp.defaultProps = {
  subTitle:'No hay subtitulo',
  name:'Maria Peralta'
}