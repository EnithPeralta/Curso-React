// iimport {heroes} from './data/heroes.js';
// mport { heroes } from "./data/heroes";
// import heroes, {owner} from '../data/heroes.js';
import heroes from '../data/heroes.js';



// console.log(owner)
// const getHeroeById = (id)=> {
//     return heroes.find((heroe) => {
//         if (heroe.id === id ) {
//             return true;
//         }else{
//             return false;
//         }
//     });
// }

export const getHeroeById = (id) => heroes.find((heroe) => heroe.id ===id)
// console.log(getHeroeById(4));

export const getHeroeByOwner =(owner)=> heroes.filter((heroe) => heroe.owner ===owner)
// console.log(getHeroeByOwner('Marvel'));

